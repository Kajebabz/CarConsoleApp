﻿
using CarConsoleApp;

// normal constructor.
Car car1 = new Car("XX 12 345", "BMW", 150);   
Car car2 = new Car("GG 98 765", "Hyundai", 70);   
Car car3 = new Car("MM 45 454", "Volvo", 115);

// tom constructor hvor vi sætter properties seperat efterfølgende.
Car car4 = new Car();
car4.RegNo = "HH 12 121";
car4.Model = "Peugeot";
car4.Hk = 90;

Console.WriteLine(car1);
Console.WriteLine(car2);
Console.WriteLine(car3);
Console.WriteLine(car4);
// Nedenstående bliver oprettet, men kun i writeline. 
//Console.WriteLine(new Car("JJ 33 333", "BWM", 200));
Console.WriteLine();
Console.WriteLine("----------------------------------------------------------------------------------");
Console.WriteLine();

CarCatalog CarCata = new CarCatalog();

// Add Cars på 2 måder.
CarCata.AddCar(car1);
CarCata.AddCar(car2);
CarCata.AddCar(car3);
CarCata.AddCar(car4);
CarCata.AddCar("LL 12 212", "Honda", 220);
CarCata.AddCar("FF 98 989", "Tesla", 385);
CarCata.AddCar("OO 22 222", "BMW", 455);
CarCata.AddCar("OO 11 111", "Kia", 455);
Console.WriteLine();
Console.WriteLine("----------------------------------------------------------------------------------");
Console.WriteLine();

// Print all cars
CarCata.PrintCars();

Console.WriteLine();
Console.WriteLine("----------------------------------------------------------------------------------");
Console.WriteLine();

// GetCar() Foreach
Console.WriteLine("--- GetCar FOREACH ---");
CarCata.GetCar("HH 12 121");
CarCata.GetCar("ÅÅ 11 111"); // Forkert
Console.WriteLine();

// GetCar1() For
Console.WriteLine("--- GetCar FOR ---");
CarCata.GetCar1("HH 12 121");
CarCata.GetCar1("ÅÅ 11 111"); // Forkert
CarCata.GetCar1("LL 12 212");
Console.WriteLine();

// GetCar2() While
Console.WriteLine("--- GetCar WHILE ---");
CarCata.GetCar2("GG 98 765");
CarCata.GetCar2("MM 45 454");
CarCata.GetCar2("ÅÅ 11 111"); // Forkert

Console.WriteLine();
Console.WriteLine("----------------------------------------------------------------------------------");
Console.WriteLine();

// DeleteCar() 
CarCata.DeleteCar("MM 45 454");
CarCata.DeleteCar("ÅÅ 11 111");

Console.WriteLine();
Console.WriteLine("----------------------------------------------------------------------------------");
Console.WriteLine();

// Ny Print hvor man ser ny liste efter Delete af: Car car3 = new Car("MM 45 454", "Volvo", 115);
CarCata.PrintCars();

Console.WriteLine();
Console.WriteLine("----------------------------------------------------------------------------------");
Console.WriteLine();

// FindAllModels() Som finder models
CarCata.FindAllModels("BMW");
Console.WriteLine();
CarCata.FindAllModels("Meh");

Console.WriteLine();
Console.WriteLine("----------------------------------------------------------------------------------");
Console.WriteLine();

// FindMaxHk() Finder bilen med højeste Hk
CarCata.FindMaxHk();

Console.WriteLine();
Console.WriteLine("----------------------------------------------------------------------------------");
Console.WriteLine();

// FindMaxHk2() Finder bilen/bilerne med højeste Hk - incase der skulle være flere med samme Hk.
CarCata.FindMaxHk2();
