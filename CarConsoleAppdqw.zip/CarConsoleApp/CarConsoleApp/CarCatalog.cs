﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CarConsoleApp
{
    public class CarCatalog
    {
        private List<Car> Cars;

        public CarCatalog()
        {
            Cars = new List<Car>(); 
        }

        public void AddCar(string regNo, string model, int hk)
        {
            Cars.Add(new Car(regNo, model, hk));
            //Car car = new Car(regNo, model, hk);
            //Cars.Add(car);
            Console.WriteLine($"new Car with RegNo: {regNo} - is now added to the catalog!");
        }
        public void AddCar (Car car)
        {
            Cars.Add(car);
            Console.WriteLine($"new Car with RegNo: {car.RegNo} - is now added to the catalog!");
        }
        public void PrintCars()
        {
            foreach (Car car in Cars)
            {
                Console.WriteLine(car);
            }
            Console.WriteLine("All Cars Listed!");
        }

        // Foreach lykke går igennem HELE listen og arbejder på hver enkelt objekt. Fordelen ved foreach lykken er at den er nemmere at skrive i forhold til at du vil igennem en hel liste.
        // Ulempen kan så samtidig også være at et foreach loop netop går igennem HELE listen. Også selvom den faktisk har fundet hvad den søgte i starten.
        public Car GetCar(string regNo)
        {
            foreach (Car car in Cars)
            {
                if (car.RegNo == regNo)
                {
                    Console.WriteLine($"Car found! - {car}");
                    return car;
                }
            }
            Console.WriteLine("No Car with the given RegNo!");
            return null;
        }

        // En For lykke forgår så længe at dens condition er true, her i < Cars.Count. Fordelen her er at du kan kontrollere præcis hvor mange gange den skal køre.
        // Ulempen ved en For lykke er at hvis jeg laver en fejl, og den aldrig bliver false, har vi et uendeligt loop.
        public Car GetCar1 (string regNo)
        {
            for (int i = 0; i < Cars.Count; i++)
            {
                Car car = Cars[i];
                if (regNo == car.RegNo)
                {
                    Console.WriteLine($"Car found! - {car}");
                    return car;
                }
            }
            Console.WriteLine("No Car with the given RegNo!");
            return null;
        }

        // En While lykke forgår ligesom en For lykke så længe at dens condition er true. Fordelen her er at man ikke behøver tage stilling til hvor mange gange den skal køre, men kun hvornår den skal stoppe.
        // Ulempen ved en While lykke er at hvis jeg laver en fejl, og den aldrig bliver false, har vi et uendeligt loop.
        public Car GetCar2 (string regNo)
        {
            int i = 0;
            while (i < Cars.Count)
            {
                Car car = Cars[i];
                if (regNo == car.RegNo)
                {
                    Console.WriteLine($"Car found! - {car}");
                    return car;
                }
                i++;
            }
            Console.WriteLine("No Car with the given RegNo!");
            return null;
        }


        public Car DeleteCar(string regNo)
        {
            foreach (Car car in Cars)
            {
                if (car.RegNo == regNo)
                {
                    Cars.Remove(car);
                    Console.WriteLine($"REMOVED from list! - {car}");
                    return car;
                }
            }
            Console.WriteLine("RegNo not found, nothing is removed!");
            return null;
        }

        public List<Car> FindAllModels(string model)
        {
            List<Car> FindModels = new List<Car>();

            foreach (Car car in Cars)
            {
                if (model == car.Model)
                {
                    FindModels.Add(car);
                }

            }
            foreach (Car car in FindModels)
            {
                Console.WriteLine(car);
            }
            if (FindModels.Count > 0)
            {
                Console.WriteLine($"Found all: {model}!");
            }
            else { Console.WriteLine("Nothing found"); }
            return FindModels;
        }

        public Car FindMaxHk()
        {
            Car MaxHkCar = Cars[0];
            foreach (Car car in Cars)
            {
                if (car.Hk > MaxHkCar.Hk)
                {
                    MaxHkCar = car;
                }
            }
            Console.WriteLine($"Car with max Hk = {MaxHkCar}");
            return MaxHkCar;
        }

        public List<Car> FindMaxHk2()
        {
            List<Car> MaxHkCarList = new List<Car>();
            MaxHkCarList.Add(Cars[0]);

            Car MaxHkCar = MaxHkCarList[0];
            foreach (Car car in Cars)
            {
                if (car.Hk > MaxHkCar.Hk)
                {
                    MaxHkCar = car;
                    MaxHkCarList.Clear();
                    MaxHkCarList.Add(car);
                }
                if (car.Hk == MaxHkCar.Hk && car.Id != MaxHkCar.Id)
                {
                    MaxHkCarList.Add(car);
                }        
            }

            foreach (Car car in MaxHkCarList)
            {
                Console.WriteLine($"Car with max Hk = {car}");
            }
            return MaxHkCarList;
        }
    }
}
