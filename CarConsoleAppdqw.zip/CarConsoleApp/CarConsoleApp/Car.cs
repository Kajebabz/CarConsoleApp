﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarConsoleApp
{
    public class Car
    {
        public Car()
        {
            Id = nextId++;
        }

        public Car(string regNo, string model, int hk)
        {
            RegNo = regNo;
            Model = model;
            Hk = hk;
            Id = nextId++;
        }

        public string RegNo { get; set; }
        public string Model { get; set; }
        public int Hk { get; set; }
        public int Id { get; set; }
        public static int nextId = 1;

        public override string ToString()
        {
            return $"{nameof(Id)}={Id.ToString()}, {nameof(RegNo)}={RegNo}, {nameof(Model)}={Model}, {nameof(Hk)}={Hk.ToString()}";
        }
    }
}
