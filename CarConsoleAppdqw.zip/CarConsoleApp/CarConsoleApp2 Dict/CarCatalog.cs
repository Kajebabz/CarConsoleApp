﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CarConsoleApp2_Dict
{
    public class CarCatalog
    {
        public Dictionary<string, Car> CarDictionary;

        public CarCatalog()
        {
            CarDictionary = new Dictionary<string, Car>();
        }

        public void AddCar(string regNo, string model, int hk)
        {
            Car car = new Car(regNo, model, hk);
            CarDictionary.Add(car.RegNo, car);
            Console.WriteLine($"new Car with RegNo: {regNo} - is now added to the catalog!");
        }

            public void AddCar (Car car)
        {
            CarDictionary.Add(car.RegNo, car);
            Console.WriteLine($"new Car with RegNo: {car.RegNo} - is now added to the catalog!");
        }

        public void PrintCars()
        {
            foreach (KeyValuePair<string, Car> entry in CarDictionary)
            {
                Console.WriteLine(entry.Value);
            }
            Console.WriteLine("All Cars Listed!");
        }

        public void PrintCars2()
        {
            foreach (var car in CarDictionary)
            {
                Console.WriteLine(car);
            }
            Console.WriteLine("All Cars Listed!");
        }

        // Giver ikke mening at bruge loop i Dictionary fordi vi har nøglen som vi bare kan slå op på, her RegNo. Her tjekker den på præcis den key igennem, den laver det samme opslag igen og igen.

        public Car GetCar(string regNo)
        {
            foreach (var entry in CarDictionary)
            {
                if (CarDictionary.ContainsKey(regNo))
                {
                    Console.WriteLine($"Car Found! - {entry.Value}");
                    return CarDictionary[regNo];
                }
            }
            Console.WriteLine("No Car with the given RegNo!");
            return null;
        }

        // Giver ikke mening at bruge loop i Dictionary fordi vi har nøglen som vi bare kan slå op på, her RegNo. Her tjekker den på præcis den key x antal gange (efter CarDictionary.Count)
        public Car GetCar1(string regNo)
        {
            for (int i = 0; i < CarDictionary.Count; i++)
            {
                if (CarDictionary.ContainsKey(regNo))
                {
                    Car car = CarDictionary[regNo];
                    Console.WriteLine($"Car Found! - {car}");
                    return car;
                }
            }
            Console.WriteLine("No Car with the given RegNo!");
            return null;
        }

        // Giver ikke mening at bruge loop i Dictionary fordi vi har nøglen som vi bare kan slå op på, her RegNo. Her tjekker den på præcis den key x antal gange (efter CarDictionary.Count)
        public Car GetCar2(string regNo)
        {
            int i = 0; 
            while (i < CarDictionary.Count)
            {
                if (CarDictionary.ContainsKey(regNo))
                {
                    Car car = CarDictionary[regNo];
                    Console.WriteLine($"Car Found! - {car}");
                    return car;
                }
                i++;
            }
            Console.WriteLine("No Car with the given RegNo!");
            return null;
        }

        // DERFOR laver vi denne GetCar() som giver mere mening i en dictionary, fordi vi prikker os direkte ind på Key.
        // Hvis vi lavede GetCar() som ikke var på RegNo som her er sat som Key, f.eks hk ville det give mening med loops.
        // Så ville loopet's formål være at finde RegNo på den bil som matcher hk.
        public Car GetCar3(string regNo)
        {
            if (CarDictionary.ContainsKey(regNo))
            {
                Car car = CarDictionary[regNo];
                Console.WriteLine($"Car Found! - {car}");
                return car;
            }
            Console.WriteLine("No Car with the given RegNo!");
            return null;
        }

        public Car DeleteCar(string regNo)
        {
            if (CarDictionary.ContainsKey(regNo))
            {
                Car car = CarDictionary[regNo];
                CarDictionary.Remove(regNo);
                Console.WriteLine($"REMOVED from list! - {car}");
                return car;
            }
            Console.WriteLine("RegNo not found, nothing is removed!");
            return null;
        }

        public List<Car> FindAllModels(string model)
        {
            List<Car> FindModels = new List<Car>();

            foreach (KeyValuePair<string, Car> entry in CarDictionary)
            {
                Car car = entry.Value;
                if (car.Model == model)
                {
                    FindModels.Add(car);
                }
            }
            foreach (Car car in FindModels)
            {
                Console.WriteLine(car);
            }
            if (FindModels.Count > 0)
            {
                Console.WriteLine($"Found all: {model}!");
            }
            else { Console.WriteLine("Nothing found"); }
            return FindModels;
        }

        public Car FindMaxHk()
        {
            // Finder den første entry med en bil i dictionary'en (referencen til den) 
            // Den bruger så nøglen på den entry vi har valgt (RegNo, altså FirstEntry.Key) til at finde selve bil objektet

            KeyValuePair<string, Car> FirstEntry = CarDictionary.First();
            Car MaxHkCar = CarDictionary[FirstEntry.Key];

            // Car MaxHkCar = CarDictionary("LL 12 212") ^^^^ Det samme .. kinda.

            foreach (KeyValuePair<string, Car> entry in CarDictionary)
            {
                Car car = entry.Value;
                if (car.Hk > MaxHkCar.Hk)
                {
                    MaxHkCar = car;
                }
            }
            Console.WriteLine($"Car with max Hk = {MaxHkCar}");
            return MaxHkCar;
        }
    }
}
